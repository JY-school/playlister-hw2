import React from "react";

export default class Banner extends React.Component {
    render() {
        return (
            <div id="banner">
                Playlister
            </div>
        );
    }
}